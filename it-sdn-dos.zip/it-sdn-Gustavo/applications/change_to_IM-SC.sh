#!/bin/bash
SDN_CONF_CD="symmcheck_sdn_cd" SDN_CONF_ND="improved_naive_sdn_nd" ./change_to_unidir.sh
