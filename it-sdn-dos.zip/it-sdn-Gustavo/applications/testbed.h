#ifndef TESTBED_H
#define TESTBED_H

#include <inttypes.h>
#define SENSORTAG_MOTE 1
#define TELOSB_MOTE 2

struct measurements_values{
  uint8_t mote_type;
  int16_t temperature;
  int16_t dec_temperature;
  int16_t humidity;
  int16_t dec_humidity;
  int16_t light;
  int16_t dec_light;
  uint32_t energy;
} __attribute__((packed));

typedef struct measurements_values measurements_values_t;

#endif /*SENSORTAG_TESTBED_H*/