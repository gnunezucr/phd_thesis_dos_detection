#ifndef ATTACK_
#define ATTACK_
void create_false_neighbor_information(uint8_t * packet, uint16_t len);
void copy_neighbor_packet(uint8_t * packet, uint16_t len); 
#endif