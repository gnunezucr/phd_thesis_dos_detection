#include <stdio.h>
#include "contiki.h"
#include "sdn-core.h"
#include "flow-table-tests.h"
#include "src-route-tests.h"
#include "sdn-debug.h"
#include "string.h"
#include "lib/random.h"
#include "ti-lib.h"
#include "board-peripherals.h"
#include "testbed.h"
#include "sdn-send-packet.h"
#include "ieee-mode.c"
// #ifdef MANAGEMENT
// #include "management-app.h"
// #endif

//#ifdef DEMO
#include "leds.h"
//#endif

#include "sys/etimer.h"

#ifndef SDN_SIMULATION_N_SINKS
#define SDN_SIMULATION_N_SINKS 1
#endif

#define SENSING_AT_SECONDS 60


/*---------------------------------------------------------------------------*/
PROCESS(sensortag_sensing_process, "Contiki SDN example process");
AUTOSTART_PROCESSES(&sensortag_sensing_process);

/*---------------------------------------------------------------------------*/
static void
receiver(uint8_t *data, uint16_t len, sdnaddr_t *source_addr, uint16_t flowId) {

  /*
  SDN_DEBUG("Receiving message from ");
  sdnaddr_print(source_addr);
  SDN_DEBUG(" of len %d: %s\n", len, (char*) data);
  */
  /* Put your code here to get data received from application. */
}

/* Use to defines either node is a sensor node and sends packets to sink or only router node and forward packets. */
static uint8_t isSensing() {

	return 1;
}

/*-----------------------------------------*/
/* Struct to save the measurements values  */
/*-----------------------------------------*/



/*--------------------------------*/
/*--------------------------------*/
/* Activates the HDC1000 sensor   */
/* (temperature and humidity)     */
/*--------------------------------*/
static void init_sensortag_temp_hum();

/*--------------------------------*/
/* Reads temperature and humidity */
/* measurements from the HDC1000  */
/* sensor                         */
/*--------------------------------*/
static void read_sensortag_temp_hum();

/*--------------------------------*/
/* Activates the OPT3001 sensor   */
/* (optical)                      */
/*--------------------------------*/
static void init_sensortag_ligh();

/*--------------------------------*/
/* Reads environmental light      */
/* measurements                   */
/*--------------------------------*/
static void read_sensortag_light();

/*-----------------------------*/
/* Activate all the sensors    */
/*-----------------------------*/
static void sensortag_sensors_init();

/*-------------------------------------*/
/* Reads measurements from all sensors */
/* and pack the results                */
/*-------------------------------------*/
static void sensortag_sensing();

/*-------------------------------*/
/* Set the measurements struct   */
/* values in 999                 */
/*-------------------------------*/
static void reset_values();

/*---------------------------------*/

static void init_sensortag_temp_hum(){
  
  SENSORS_ACTIVATE(hdc_1000_sensor);  
}

static void init_sensortag_ligh(){

  SENSORS_ACTIVATE(opt_3001_sensor);  
}


static void read_sensortag_temp_hum(measurements_values_t *values_t){
  
  int value;

  value = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_TEMP);
  if(value != CC26XX_SENSOR_READING_ERROR) {
    values_t->temperature = (uint16_t)(value/100);
    values_t->dec_temperature = (uint16_t)(value % 100);
    printf("HDC: Temp=%d.%02d C\n", (int)values_t->temperature, (int)values_t->dec_temperature);
  } else {
    printf("HDC: Temp Read Error\n");
  }

  value = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_HUMIDITY);
  if(value != CC26XX_SENSOR_READING_ERROR) {
    values_t->humidity = (uint16_t)(value/100);
    values_t->dec_humidity = (uint16_t)(value % 100);
    printf("HDC: Humidity=%d.%02d %%RH\n", (int)values_t->humidity, (int)values_t->dec_humidity);
  } else {
    printf("HDC: Humidity Read Error\n");
  }

  SENSORS_DEACTIVATE(hdc_1000_sensor);
}

static void read_sensortag_light(measurements_values_t *values_t){

  int value;

    value = opt_3001_sensor.value(0);
  if(value != CC26XX_SENSOR_READING_ERROR) {
    values_t->light = (uint16_t)(value/100);
    values_t->dec_light =  (uint16_t)(value % 100);
    printf("OPT: Light=%d.%02d lux\n", (int)values_t->light, (int)values_t->dec_light);
  } else {
    printf("OPT: Light Read Error\n");
  }
  //SENSORS_DEACTIVATE(opt_3001_sensor);
}


static void sensortag_sensors_init(){
  init_sensortag_ligh();
  init_sensortag_temp_hum();
}

static void sensortag_sensing(measurements_values_t *values_t){
  read_sensortag_temp_hum(values_t);
  read_sensortag_light(values_t);
}

static void reset_values(measurements_values_t *values_t){

  values_t->temperature = 999;
  values_t->dec_temperature = 999;
  values_t->humidity = 999;
  values_t->dec_humidity = 999;
  values_t->light = 999;
  values_t->dec_light = 999;
}


/*---------------------------------------------------------------------------*/
PROCESS_THREAD(sensortag_sensing_process, ev, data)
{

  PROCESS_BEGIN();

  set_tx_power(-21);

  printf("SENSING EVERY SECONDS = %i\n", SENSING_AT_SECONDS);

  sdn_init(receiver);

  static flowid_t sink;

  sink = 2017 + (sdn_node_addr.u8[0] % SDN_SIMULATION_N_SINKS);

  printf("SENSORTAG ENVIRONMENTAL MONITORING \n");

  static struct etimer periodic_timer;

  if(isSensing() == 1) {
    printf("Sensing data node.\n");
    printf("#A color=GREEN\n");
  } else {
    printf("#A color=BLUE\n");
  }

  etimer_set(&periodic_timer, (360 + random_rand() % SENSING_AT_SECONDS) * CLOCK_SECOND) ;

  PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

  if(isSensing() == 1) {
    etimer_set(&periodic_timer, SENSING_AT_SECONDS * CLOCK_SECOND);
  }

  measurements_values_t measurements_t;
  
  sensortag_sensors_init();

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));
   
    //leds_toggle(LEDS_RED);

    etimer_restart(&periodic_timer);

    sensortag_sensing(&measurements_t);

    measurements_t.mote_type = SENSORTAG_MOTE;
    
    printf("Sending data to sink\n");

    sdn_send((uint8_t*)&measurements_t, sizeof(measurements_values_t), sink);
    
    reset_values(&measurements_t);

    // sdn_send_data_management(7);

    // init_sensortag_temp_hum();

    sensortag_sensors_init();
  }

  PROCESS_END();
}