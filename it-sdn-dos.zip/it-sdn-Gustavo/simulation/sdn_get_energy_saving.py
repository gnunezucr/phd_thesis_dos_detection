import re, sys
from collections import defaultdict
import matplotlib.pyplot as plt
import math
import numpy as np
import scipy.stats


STAT_DESV = "CONF_INTERVAL"
STAT_CONFIDENCE = 0.95

# MARKOV = 0
# ARIMA = 1

def parse_file(filename):
	print "Parsing", filename
	energy_node = defaultdict(int)




	# Markov simulations
	# 242485216:23:Energy consumption = 16213
	expression = re.compile(r""" (?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*Energy\sconsumption\s=[ \t]{1,}(?P<CONS>\d+)""", re.X) 
	# expression_2 = re.compile(r""" (?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*Consumption\s2:[ \t]{1,}(?P<CONS>\d+)""", re.X) 
	# ARIMA simulations
	# expression = re.compile(r""" (?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*Energy\sconsumption:\s\s (?P<CONS>\d+)""", re.X)


# First field is time, we do not match any pattern 
# ID field is different in Cooja GUI and command line (ID: or just a :)
# the actual id is a sequence of numbers 
# finishing id pattern (colon or space) and matching everything else until getting what we want
# constant expression
# Real consumption value
#consumption forecasted
#re.X: verbose so we can comment along

	energy_list = defaultdict(list)
	energy_average = defaultdict(int)
	energy_per_hop = defaultdict(list)
	energy_avg_list = list()

	timeExpr = re.compile("(?:(\d+)?:?(\d\d):(\d\d).)?(\d+)")

	try:
		f = file(filename)
	except:
		print "error on f = file(filename)"
		return

	for l in f:
		# print l.strip()
		s = expression.search(l)
		if s != None:
			# print s.groups()
			time, nodeid, consumption = s.groups()

			# Markov simulations
			energy = int(consumption)
			# ARIMA simulations
			#if int(consumption) < 999999:	
			#	energy = int(consumption) * 6 * 0.001
			
			energy_list[nodeid] += [energy]


	# for k,v in energy_list.iteritems():
	# 	energy_avg_list += v

	for k in energy_list.iterkeys():
		energy_avg_list.append(max(energy_list[k]))

	# for k,v in energy_list.iteritems():
	# 	energy_avg_list += v

	print energy_avg_list

	energy_avg = np.mean(energy_avg_list)
	energy_std = np.std(energy_avg_list)
	# dest_avg_list  = np.std(list(error_list.values()))
	# for k in error_list:
		# case para ver em que hop colocar
		# definir antes os hops, usar diccionarios
		# 
	#    if 
	results_summary = (energy_avg, energy_std)
	print results_summary
	return results_summary


def dir_path(topo_name):
    if topo_name == 'a1_1' or topo_name == 'a1_3':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a1/"
        return results_dir

    elif topo_name == 'a2_1' or topo_name == 'a2_3':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a2/"
	print("A2 topology")
	return results_dir

    elif topo_name == 'a3_1' or topo_name == 'a3_3':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a3/"
        return results_dir

    elif topo_name == 'bl':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/bl_sembei/"
        return results_dir

    elif topo_name == 'a2_1_10' or topo_name == 'a2_3_10':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a2_10/"
        return results_dir

    else:
        print("Invalid topology") 


if __name__ == "__main__":


	if len(sys.argv) == 2:
		parse_file(sys.argv[1])
		exit(0)


	#nodes_v = (36,)
	nodes_v = (36, 49, 64, 81, 100, 121)
	#nodes_v = (81,)
	topologies = ('a1_3', 'a2_3', 'a3_3')
	#topologies = ('a1_1',)

	MIN_ITER=1
	MAX_ITER=10
	sim_time = 60.0


	partial_results = defaultdict(list)
	# results_by_hops = defaultdict(dict)
	results_n = defaultdict(lambda: defaultdict(int))
	results_sum = defaultdict(lambda: defaultdict(int))
	results_sum2 = defaultdict(lambda: defaultdict(int))

	results_avg = defaultdict(dict)
	results_desv = defaultdict(dict)
	f_all = file("energy_all.txt", 'w')
	f_summary = file("energy_summary.txt", 'w')



	for nnodes in nodes_v:
		for topo in topologies:
			scenario = (nnodes, topo)
			for i in range(MIN_ITER, MAX_ITER+1):
				#filename = "Energy_test2_n" + repr(nnodes) + "_top" + topo + "_i" + repr(i) + '.txt'
				filename = "ITSDN_n" + repr(nnodes) + "_top_" + topo + "_i" + repr(i) + '.txt'
				r = parse_file(dir_path(topo) + filename)
				partial_results[scenario] += [r]

	# metric_names = ("total_error", "1_hop_error", "2_hop_error", "3_hop_error", "4_hop_error", "5+_hop_error")
	# print partial_results
	metric_names = ("Average_energy", "standard_deviation")
	energy_final = ("Average_energy",)
	f_all.write("scenario;")
	f_all.write(";".join(metric_names))
	f_all.write("\n")

	for scenario, results_list in sorted(partial_results.iteritems()):
		for metric_list in results_list:
			if metric_list == None:
				continue
			f_all.write(repr(scenario) + ";")
			for i_metric in range(len(metric_list)):
				if metric_list[i_metric] > 0:
					results_n[scenario][i_metric] += 1
					results_sum[scenario][i_metric] += metric_list[i_metric]
					results_sum2[scenario][i_metric] += metric_list[i_metric] * metric_list[i_metric]
					f_all.write(repr(metric_list[i_metric]) + ";")
				else:
					f_all.write("-1;")

			for i_metric in range(len(metric_list)):
				if not results_n[scenario].has_key(i_metric):
					results_n[scenario][i_metric] = 0
					results_sum[scenario][i_metric] = 0
					results_sum2[scenario][i_metric] = 0

			f_all.write("\n")

	for scenario in results_n.keys():
		print scenario
		for i_metric in results_n[scenario].keys():
			c, s, s2 = results_n[scenario][i_metric], results_sum[scenario][i_metric], results_sum2[scenario][i_metric]
			print metric_names[i_metric],
			if c:
				avg = 1.0 * s / c
				print avg,
				results_avg[i_metric][scenario] = avg
			else:
				results_avg[i_metric][scenario] = 0
			if c-1 > 0:
				desv = 1
				if (1.0*s2 - 1.0*s*s/c) >= 0:
					desv = math.sqrt((1.0*s2 - 1.0*s*s/c)/(c-1))
				print desv
				if STAT_DESV == "STD_DEV":
					results_desv[i_metric][scenario] = desv
				elif STAT_DESV == "CONF_INTERVAL":
					pvalue = scipy.stats.t.ppf(1 - (1-STAT_CONFIDENCE)/2, c-1)
					results_desv[i_metric][scenario] = desv * pvalue / math.sqrt(c)
			else:
				print
				results_desv[i_metric][scenario] = 0

#quitar if metric_list[i_metric] > 0: para ver el error 

	for i_metric in range(len(energy_final)):
		print "writing to file", energy_final[i_metric]
		f_summary.write(repr(energy_final[i_metric]) + '\n')
		f_summary.write('scenario;average;std deviation\n')
		for scenario in sorted(results_avg[i_metric].keys()):
			f_summary.write(repr(scenario) + ";")
			f_summary.write(repr(results_avg[i_metric][scenario]) + ";")
			f_summary.write(repr(results_desv[i_metric][scenario]) + ";\n")
		f_summary.write("\n")

#########################################################
############ Plotting ###################################
#########################################################

	# colors = ("red", "green", "cyan", "gray", "orange", "pink")
	# colors = ("#d73027", "#fc8d59", "#fee090", "#e0f3f8", "#91bfdb", "#4575b4")
	# colors = ("#f7f7f7", "#d9d9d9", "#bdbdbd", "#969696", "#636363", "#252525")
	# colors = ("#f7f7f7", "#bdbdbd", "#d9d9d9", "#636363", "#969696", "#353535")
	# colors = ("#ffffb2", "#fdae6b", "#c7e9c0", "#de2d26", "#9e9ac8", "#353535", "#212121", "#090990")
	# # colors = ("#ffffb2", "#fdae6b", "#c7e9c0")
	# hatches = ('//', '', '\\\\', 'o', '-', '+', 'x', '*', 'O', '.', '/', '\\')
	# plt.rcParams.update({'font.size': 16, 'legend.fontsize': 14})
	# fig = plt.figure()
	# ax = fig.add_subplot(1, 1, 1)
	# plt.grid(b=True, which='major', color='gray', linestyle='--', lw=0.1, axis='y')
	# print
	# print "ploting error"
	# i_metric = 0
	# bar_width = 0.8/len(results_avg[i_metric].keys())
	# x = np.arange(2)
	# i = 0
	# for scenario in sorted(results_avg[i_metric].keys()):
	# 	y = (results_avg[i_metric][scenario], results_avg[i_metric+1][scenario])
	# 	desv = (results_desv[i_metric][scenario], results_desv[i_metric+1][scenario])
	# 	print x + bar_width*i, y, bar_width
	# 	plt.bar(x + bar_width*(i + i/len(colors)/2.0), y, bar_width, yerr=desv, color=colors[i%len(colors)], hatch=hatches[i/len(colors)], ecolor='black' )
	# 	i+=1
	# 	# print x
	# 	# print y
	# # plt.errorbar(x, y, e, ls=lss[rc], color=colors[rc], marker=markers[rc])
	# plt.xlabel('Packet Type')
	# plt.ylabel('Error [%]')
	# plt.xticks(x + bar_width * len(results_avg[i_metric].keys()) / 2, ('Data', 'Control'))
	# # plt.legend(ncol=3)
	# axes = plt.gca()
	# axes.set_xlim([-bar_width/2, 1 + bar_width*(i + i/len(colors)/2.0) ])

	# plt.savefig('r_error.eps', format='eps', dpi=1000)