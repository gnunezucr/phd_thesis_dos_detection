import re, sys
from collections import defaultdict
import matplotlib.pyplot as plt
import math
import numpy as np
import scipy.stats


STAT_DESV = "CONF_INTERVAL"
STAT_CONFIDENCE = 0.95

MARKOV = 0
ARIMA = 1

def parse_file(filename, n_nodes, topo_name):
	print "Parsing", filename
	energy_node = defaultdict(int)

	if topo_name == 'a1_1' or topo_name == 'a2_1' or topo_name == 'a3_1' or topo_name == 'a2_1_10' or topo_name == 'bl':
		if n_nodes == 36:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!28|0D|0A|1F)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!28|0D|0A|1F)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations

		elif n_nodes == 49:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!35|0F|0B|2B|27)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!35|0F|0B|2B|27)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations

		elif n_nodes == 64:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!44|06|0C|34|10|29|38)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!44|06|0C|34|10|29|38)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations    	


		elif n_nodes == 81:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!55|0C|30|20|44|59|44|58|48)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!55|0C|30|20|44|59|44|58|48)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)

	            
		elif n_nodes == 100:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!66|15|3D|03|2B|53|13|66|3B|4D|63)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!66|15|3D|03|2B|53|13|66|3B|4D|63)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)


		elif n_nodes == 121:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!7B|02|2E|5A|1A|46|72|08|20|34|4C|60|78)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!7B|02|2E|5A|1A|46|72|08|20|34|4C|60|78)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)

		else:
			print("Topology size not valid") 


    
	if topo_name == 'a1_3' or topo_name == 'a2_3' or topo_name == 'a3_3' or topo_name == 'a2_3_10': 

		if n_nodes == 36:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!28|29|2A)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!28|29|2A)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations

		elif n_nodes == 49:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!35|36|37|38)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!35|36|37|38)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations

		elif n_nodes == 64:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!44|45|46|47|48|49)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!44|45|46|47|48|49)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
		# ARIMA simulations    	


		elif n_nodes == 81:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!55|56|57|58|59|5A|5B|5C)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!55|56|57|58|59|5A|5B|5C)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)

	            
		elif n_nodes == 100:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!66|67|68|69|6A|6B|6C|6D|6E|6F)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!66|67|68|69|6A|6B|6C|6D|6E|6F)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)


		elif n_nodes == 121:
			expression = re.compile(r"""
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!7B|7C|7D|7E|7F|80|81|82|83|84|85|86)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
			expression_2 = re.compile(r""" 
				(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>(?!7B|7C|7D|7E|7F|80|81|82|83|84|85|86)[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)

		else:
			print("Topology size not valid") 

	# expression = re.compile(r"""
	# 	(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Control\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)
	# expression_2 = re.compile(r""" 
	# 	(?P<TIME>.*)(?:\s.*ID:|:)(?P<ID>\d+)(?:\s|:).*\[\s(?P<IDSEND>[0-9A-F]{2})\s[0-9A-F]{2}\s\].*Data\sflow\sused\s(?P<TIMES>\d+).+times""", re.X)


	control_list = defaultdict(list)
	data_list = defaultdict(list)
	control_total = defaultdict(int)
	data_total = defaultdict(int)
	control_per_time = defaultdict(list)
	data_per_time = defaultdict(list)

	control_total_per_time = defaultdict(int)
	data_total_per_time = defaultdict(int)

	time_register_control = 0
	time_index_control = 3
	time_flag_control = 0
	time_register_data = 0
	time_index_data = 3
	time_flag_data = 0

	timeExpr = re.compile("(?:(\d+)?:?(\d\d):(\d\d).)?(\d+)")

	try:
		f = file(filename)
	except:
		print "error on f = file(filename)"
		return

	for l in f:
		# print l.strip()
		s = expression.search(l)
		if s != None:
			# print s.groups()
			# print ("Found a match")
			timecontrol, nodeidcontrol, idsendcontrol, timescontrol = s.groups()
			if time_flag_control is 0:
				time_register_control = int(timecontrol)
				time_flag_control = 1
		
			timescontrol = int(timescontrol)
			control_list[idsendcontrol] += [timescontrol]
			control_per_time[time_index_control] += [timescontrol]

			temp_time_control = float(float((int(timecontrol) - int(time_register_control)))/1000000)
			if temp_time_control > 179.9:
				time_register_control =  int(timecontrol)
				time_index_control = time_index_control + 3
				time_flag = 0


		s = expression_2.search(l)
		if s != None:
				# print s.groups()
			timedata, nodeiddata, idsenddata, timesdata = s.groups()
			if time_flag_data is 0:
				time_register_data = int(timedata)
				time_flag_data = 1
		
			timesdata = int(timesdata)
			data_list[idsenddata] += [timesdata]
			data_per_time[time_index_data] += [timesdata]

			temp_time_data = float(float((int(timedata) - int(time_register_data)))/1000000)
			if temp_time_data > 179.9:
				time_register_data =  int(timedata)
				time_index_data = time_index_data + 3



	# for k,v in energy_list.iteritems():
	# 	energy_avg_list += v



	for k,v in control_per_time.items():
		control_total_per_time[k] = sum(v)

	# print control_total_per_time

	for k,v in data_per_time.items():
		data_total_per_time[k] = sum(v)

	# print data_total_per_time	

	# energy_avg = np.mean(energy_avg_list)
	# energy_std = np.std(energy_avg_list)
	# dest_avg_list  = np.std(list(error_list.values()))

	# for k in error_list:
		# case para ver em que hop colocar
		# definir antes os hops, usar diccionarios
		# 
	#    if 
	results_summary = (control_total_per_time, data_total_per_time)
	return results_summary 


def dir_path(topo_name):
    if topo_name == 'a1_1' or topo_name == 'a1_3':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a1/"
        return results_dir

    elif topo_name == 'a2_1' or topo_name == 'a2_3':
    	results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a2/"
	return results_dir

    elif topo_name == 'a3_1' or topo_name == 'a3_3':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a3/"
        return results_dir

    elif topo_name == 'bl':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/bl_sembei/"
        return results_dir

    elif topo_name == 'a2_1_10' or topo_name == 'a2_3_10':
        results_dir = "/home/gnunez/Results/VLIoT_2019/results_bl_a1_a2_a3/a2_10/"
        return results_dir

    else:
        print("Invalid topology")

if __name__ == "__main__":


	if len(sys.argv) == 2:
		parse_file(sys.argv[1])
		exit(0)


	#nodes_v = (36, 49, 64, 81, 100, 121) 
	nodes_v = (49, )
	# topologies = ('a1_1', 'a2_1', 'a3_1', 'a1_3', 'a2_3', 'a3_3')
	#topologies = ('bl', 'a1_1', 'a2_1', 'a3_1', 'a1_3', 'a2_3', 'a3_3', 'a2_1_10', 'a2_3_10')
	topologies = ('a1_3',)
	MIN_ITER=1
	MAX_ITER=10
	sim_time = 60.0

	# results_dir = "results_ARIMA_Node/"
	# results_dir = "results_ARIMA_PC/"
	# results_dir = "2_results_ARIMA_Node/"

	partial_results = defaultdict(list)

	control_partial_results = defaultdict(list)
	data_partial_results = defaultdict(list)
	# results_by_hops = defaultdict(dict)
	results_n = defaultdict(lambda: defaultdict(int))
	results_sum = defaultdict(lambda: defaultdict(int))
	results_sum2 = defaultdict(lambda: defaultdict(int))

	results_avg = defaultdict(dict)
	results_desv = defaultdict(dict)
	f_all = file("flows_all.txt", 'w')
	f_summary = file("flows_summary.txt", 'w')



	for nnodes in nodes_v:
		for topo in topologies:
			scenario = (nnodes, topo)
			for i in range(MIN_ITER, MAX_ITER+1):
				#filename = "Energy_test2_n" + repr(nnodes) + "_top" + topo + "_i" + repr(i) + '.txt'
				filename = "ITSDN_n" + repr(nnodes) + "_top_" + topo + "_i" + repr(i) + '.txt'
				print (filename)
				results_dir = dir_path(topo)
				if results_dir != None:
					r = parse_file(results_dir + filename, nnodes, topo)
					for k,v in r[0].iteritems():
						control_partial_results[k].append(v)
					for k,v in r[1].iteritems():
						data_partial_results[k].append(v)
			# print(data_partial_results)
			avg_control = defaultdict(int)
			desv_control = defaultdict(int)

			avg_data = defaultdict(int)
			desv_data = defaultdict(int)

			print (control_partial_results)
			print ("test")
			for k,v in control_partial_results.items():
				avg_control[k] = sum(v)/len(v)
				desv_control[k] = np.std(v, ddof=1)

			for k,v in data_partial_results.items():
				avg_data[k] = sum(v)/len(v)
				desv_data[k] = np.std(v, ddof=1)

			f = (avg_control, desv_control, avg_data, desv_data)
			partial_results[scenario] += [f]
			#control_partial_results = defaultdict(list)
			#data_partial_results = defaultdict(list)

	
	# print (partial_results)
	# metric_names = ("total_error", "1_hop_error", "2_hop_error", "3_hop_error", "4_hop_error", "5+_hop_error")
	# print partial_results
 	metric_names = ("Control_flows", "Data_flows")
# 	energy_final = ("Average_energy",)
 	f_all.write("scenario;")
 	f_all.write(";".join(metric_names))
 	f_all.write("\n")



 	for scenario, results_list in sorted(partial_results.items()):
 		# print('scenario:', scenario, '\n')
 		f_summary.write("scenario:" + repr(scenario))
 		f_summary.write('\n')
 		for metrics_list in results_list:
 			for k in metrics_list:
 				f_summary.write("---------------------\n")
 				for v, f in sorted(k.items()):
 					f_summary.write(repr(f))
 					# f_summary.write(repr(v) + '\t' + repr(f))
 					f_summary.write('\n')
 					# print(v, f)



	# print (partial_results)
 	# for scenario, results_list in sorted(partial_results.iteritems()):
 	# 	print (results_list)
 	# 	for metric_list in results_list:
 	# 		print (metric_list[1])
#		for metric_list in results_list:
#			#print metric_list

# 	for scenario, results_list in sorted(partial_results.iteritems()):
# 		for metric_list in results_list:
# 			if metric_list == None:
# 				continue
# 			f_all.write(repr(scenario) + ";")
# 			for i_metric in range(len(metric_list)):
# 				if metric_list[i_metric] > 0:
# 					results_n[scenario][i_metric] += 1
# 					results_sum[scenario][i_metric] += metric_list[i_metric]
# 					results_sum2[scenario][i_metric] += metric_list[i_metric] * metric_list[i_metric]
# 					f_all.write(repr(metric_list[i_metric]) + ";")
# 				else:
# 					f_all.write("-1;")

# 			for i_metric in range(len(metric_list)):
# 				if not results_n[scenario].has_key(i_metric):
# 					results_n[scenario][i_metric] = 0
# 					results_sum[scenario][i_metric] = 0
# 					results_sum2[scenario][i_metric] = 0

# 			f_all.write("\n")

# 	for scenario in results_n.keys():
# 		print scenario
# 		for i_metric in results_n[scenario].keys():
# 			c, s, s2 = results_n[scenario][i_metric], results_sum[scenario][i_metric], results_sum2[scenario][i_metric]
# 			print metric_names[i_metric],
# 			if c:
# 				avg = 1.0 * s / c
# 				print avg,
# 				results_avg[i_metric][scenario] = avg
# 			else:
# 				results_avg[i_metric][scenario] = 0
# 			if c-1 > 0:
# 				desv = 1
# 				if (1.0*s2 - 1.0*s*s/c) >= 0:
# 					desv = math.sqrt((1.0*s2 - 1.0*s*s/c)/(c-1))
# 				print desv
# 				if STAT_DESV == "STD_DEV":
# 					results_desv[i_metric][scenario] = desv
# 				elif STAT_DESV == "CONF_INTERVAL":
# 					pvalue = scipy.stats.t.ppf(1 - (1-STAT_CONFIDENCE)/2, c-1)
# 					results_desv[i_metric][scenario] = desv * pvalue / math.sqrt(c)
# 			else:
# 				print
# 				results_desv[i_metric][scenario] = 0

# #quitar if metric_list[i_metric] > 0: para ver el error 

	# for i_metric in range(len(energy_final)):
	# 	print "writing to file", energy_final[i_metric]
	# 	f_summary.write(repr(energy_final[i_metric]) + '\n')
	# 	f_summary.write('scenario;average;std deviation\n')
	# 	for scenario in sorted(results_avg[i_metric].keys()):
	# 		f_summary.write(repr(scenario) + ";")
	# 		f_summary.write(repr(results_avg[i_metric][scenario]) + ";")
	# 		f_summary.write(repr(results_desv[i_metric][scenario]) + ";\n")
	# 	f_summary.write("\n")