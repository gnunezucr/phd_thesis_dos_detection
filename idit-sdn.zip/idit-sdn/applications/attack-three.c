/*
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain this list of conditions
 *    and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * THE SOFTWARE PROVIDER OR DEVELOPERS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/************************************************************************/
/* attack-one.c : Initially, the node is part of the network and after  */
/* ATTACK_TRIGGER seconds, it starts to send data packets with unknown  */
/* flows to their neighbors.                                            */
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "contiki.h"
#include "sdn-core.h"
#include "flow-table-tests.h"
#include "src-route-tests.h"
#include "sdn-debug.h"
#include "string.h"
#include "lib/random.h"
#include "collect-nd.h"
#include "net/netstack.h"
#include "sdn-process-packets.h"
#include "sdn-common-send.h"

#ifdef DEMO
#include "leds.h"
#endif

#include "sys/etimer.h"

#ifndef SDN_SIMULATION_N_SINKS
#define SDN_SIMULATION_N_SINKS 1
#endif

#define SENSING_AT_SECONDS 60
#define IDS_TIMER 120
#define ATTACK_TRIGGER 7000
#define RANDOM_TRIGGER 1200
// #define ATTACK_TRIGGER 30600
// #define RANDOM_TRIGGER 72
#ifdef ATTACK_SIXTY
#define ATTACK_PERIOD 60
#endif
#ifdef ATTACK_THIRTY
#define ATTACK_PERIOD 30
#endif
#ifdef ATTACK_TEN
#define ATTACK_PERIOD 10
#endif
#ifdef ATTACK_ONE
#define ATTACK_PERIOD 1
#endif

uint8_t attack;

/*---------------------------------------------------------------------------*/
PROCESS(sdn_test_process, "Contiki SDN example process");
AUTOSTART_PROCESSES(&sdn_test_process);


uint16_t temp_flowid[8];


uint8_t flag[4];
uint8_t* neighbor[4];

uint16_t len_neighbor[4];

/*---------------------------------------------------------------------------*/
static void
receiver(uint8_t *data, uint16_t len, sdnaddr_t *source_addr, uint16_t flowId) {

  SDN_DEBUG("Receiving message from ");
  sdnaddr_print(source_addr);
  SDN_DEBUG(" of len %d: %s\n", len, (char*) data);

  /* Put your code here to get data received from application. */
}
/*-----------------------------------------------------------------------------*/
/* Use to defines either node is a sensor node and sends packets to sink or only router node and forward packets. */
static uint8_t isSensing() {

  uint8_t sensing = 0;

  sensing = 1;

  return sensing;
}

void create_false_neighbor_information(uint8_t * packet, uint16_t len);

void create_false_neighbor_information(uint8_t * packet, uint16_t len) {

 /*We count the number of neighbors and do a random from 0 to # of neigbors*/
/*The random result is the number of neighbors that will be remove (or modified) from the table*/  
    printf("Printing packet\n");
    print_packet(packet, len);
    #ifdef ETX_MODIF 
    uint8_t n_neighbors;
    memcpy(&n_neighbors, packet + 8, sizeof(n_neighbors));
    
    //printf("Before ETX modification");
    //print_packet(packet, len);

    uint8_t i;
    for (i = 11; i < len; i=i+4) {
      uint16_t temp_etx;
      uint16_t new_etx;
      memcpy(&temp_etx, packet + i, sizeof(temp_etx));
      printf("Current ETX= %u\n", temp_etx);
      new_etx = 8 + (random_rand() % 100);
      memcpy(packet + i, &new_etx, sizeof(new_etx));
      printf("New ETX= %u\n", new_etx);
    }

    //printf("After ETX modification");
    //print_packet(packet, len);
    #endif
    
    #ifdef ADDR_MODIF
    printf("Before ADDR modification \n");
    //print_packet(packet, len);

    uint8_t a;
    for (a = 9; a < len; a=a+4) {
      uint16_t new_addr;
      new_addr = 4 + (random_rand() % 20);
      memcpy(packet + a, &new_addr, sizeof(new_addr));
      //printf("New Address= %u\n", new_etx);
    }

    printf("After ADDR modification\n");
    //print_packet(packet, len);
    #endif
    ENQUEUE_AND_SEND(packet, len, 0);
   //sdn_treat_packet(packet, len, 0);
}

void copy_neighbor_packet(uint8_t * packet, uint16_t len) {

  printf("Copying neighbor reports\n");
  if (flag[0] == 0) {
    printf("Printing 1\n");
    print_packet(packet, len);
    neighbor[0] = (uint8_t*)malloc(len);
    memcpy(neighbor[0], packet, len);
    len_neighbor[0] = len;
    print_packet(neighbor[0], len);
    flag[0] = 1;
    return;
  }

  if (flag[1] == 0) {
    neighbor[1] = (uint8_t*)malloc(len);
    memcpy(neighbor[1], packet, len);
    len_neighbor[1] = len;
    flag[1] = 1;
    return;
  }

  if (flag[2] == 0) {
    neighbor[2] = (uint8_t*)malloc(len);
    memcpy(neighbor[2], packet, len);
    len_neighbor[2] = len;
    flag[2] = 1;
    return;
  }

  if (flag[3] == 0) {
    neighbor[3] = (uint8_t*)malloc(len);
    memcpy(neighbor[3], packet, len);
    len_neighbor[3] = len;
    flag[3] = 1;
    return;
  }
}

/*---------------------------------------------------------------------------*/
PROCESS_THREAD(sdn_test_process, ev, data)
{
  PROCESS_BEGIN();

/*
  NETSTACK_RADIO.off();

  static struct etimer sdn_timer;
  etimer_set(&sdn_timer, (600 + random_rand() % 300) * CLOCK_SECOND);
  PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&sdn_timer));

  NETSTACK_RADIO.on();
*/

  printf("SENSING AT SECONDS = %i\n", SENSING_AT_SECONDS);

  sdn_init(receiver);

  static flowid_t sink;

  sink = 2017 + (sdn_node_addr.u8[0] % SDN_SIMULATION_N_SINKS);

  printf("SDN_SIMULATION_N_SINKS %d\n", SDN_SIMULATION_N_SINKS);

  static struct etimer periodic_timer;
  static struct etimer ids_timer;
  static struct etimer attack_timer;

  if(isSensing() == 1) {
    printf("Sensing data node.\n");
    printf("#A color=GREEN\n");
  } else {
    printf("#A color=BLUE\n");
  }

  etimer_set(&periodic_timer, (120 + random_rand() % SENSING_AT_SECONDS) * CLOCK_SECOND) ;

  PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

  if(isSensing() == 1) {
    etimer_set(&periodic_timer, SENSING_AT_SECONDS * CLOCK_SECOND);
  }

  etimer_set(&ids_timer, IDS_TIMER * CLOCK_SECOND);
  etimer_set(&attack_timer, (ATTACK_TRIGGER +  random_rand() % RANDOM_TRIGGER) * CLOCK_SECOND);
  //ctimer_set(&attack_timer, ATTACK_TRIGGER * CLOCK_SECOND, create_false_flows, NULL);
  //printf("Flag timer = %u\n", ATTACK_TRIGGER +  random_rand() % RANDOM_TRIGGER);

  static char data[10];
  static uint8_t i = 0;
  static uint8_t counter = 0;

  while(1) {
    PROCESS_WAIT_EVENT();

    if (etimer_expired(&periodic_timer)) {

      sprintf(data, "teste %d", i++);

      SDN_DEBUG("Sending data to flow %d\n", sink);

      sdn_send((uint8_t*) data, 10, sink);

      etimer_restart(&periodic_timer);
      counter++;
    }

/*
    if (counter == 3) {
      etimer_set(&ids_timer, 2 * CLOCK_SECOND);
      PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&ids_timer));
      counter = 0;
      printf("Sending IDS data to Management server\n");
      uint16_t mngt_metrics;
      mngt_metrics = 26;
      sdn_send_data_management(mngt_metrics);
      //printf("Energy consumption = %lu\n", consumed_energy());
      etimer_reset(&ids_timer);

    } 
*/
    if (etimer_expired(&attack_timer)) {
      attack = 1;
      uint8_t n_random;
      n_random = random_rand() % 4;
      if (flag[n_random] == 1) {
        create_false_neighbor_information(neighbor[n_random], len_neighbor[n_random]);
      }else if (flag[0] == 1) {
        n_random = 0;
        create_false_neighbor_information(neighbor[n_random], len_neighbor[n_random]);
      }
      etimer_set(&attack_timer, ATTACK_PERIOD * CLOCK_SECOND);
    }
/*
    if (etimer_expired(&ids_timer)) {
      
      printf("Sending IDS data to controller\n");
      uint16_t mngt_metrics;
      mngt_metrics = 24;
      sdn_send_data_management(mngt_metrics, 2);
      etimer_reset(&ids_timer);
    }
*/
  }

  PROCESS_END();
}
